document.getElementById('open-signin-popup').addEventListener('click', function() {
    document.getElementById('signin-popup').style.display = 'block';
});

document.getElementById('close-signin-popup').addEventListener('click', function() {
    document.getElementById('signin-popup').style.display = 'none';
});
